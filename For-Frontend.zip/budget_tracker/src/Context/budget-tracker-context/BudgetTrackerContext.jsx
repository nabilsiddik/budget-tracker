import axios from 'axios'
import React, { createContext, useEffect, useState } from 'react'

const budgetTrackerContext = createContext()


const BudgetTrackerContext = (props) => {

  const [budgets, setBudges] = useState([])
  const [expenses, setExpenses] = useState([])

  // Load Budgets Data
  const loadBudgets = async () => {
    const result = await axios.get("http://localhost:8080/budget")
    setBudges(result.data)
  }

  // Load Expenses Data
  const loadExpense = async () => {
    const result = await axios.get("http://localhost:8080/expense")
    setExpenses(result.data)
  }


  // Calculate total Spent amount
  const totalSpentAmountForSpecificBudgetCategory = (budgetcategory) => {
    let totalSpentAmount = 0
    expenses.map((expense) => {
      if (expense.budgetcategory.toLowerCase() === budgetcategory.toLowerCase()) {
        totalSpentAmount += expense.expenseamount
      }
    })
    return totalSpentAmount
  }



  // Delete budget
  const deleteBudget = async (budgetId, budgetName) => {
    axios.delete(`http://localhost:8080/budget/${budgetId}`)
    loadBudgets()
    deleteRelatedExpenses(budgetName)
  }

  // Delete Expense
  const deleteExpense = async (id) => {
    await axios.delete(`http://localhost:8080/expense/${id}`)
    loadExpense()
  }

  // Delete related Expenses on Delete specific Budget
  const deleteRelatedExpenses = (budgetName) => {
    expenses.map((expense) => {
      if (expense.budgetcategory.toLowerCase() === budgetName.toLowerCase()) {
        deleteExpense(expense.id)
      }
    })
  }




  const contextValue = {
    budgets,
    expenses,
    loadBudgets,
    loadExpense,
    totalSpentAmountForSpecificBudgetCategory,
    deleteBudget,
    deleteExpense,
    deleteRelatedExpenses
  }

  return (
    <budgetTrackerContext.Provider value={contextValue}>
      {props.children}
    </budgetTrackerContext.Provider>
  )
}

export { BudgetTrackerContext, budgetTrackerContext }
