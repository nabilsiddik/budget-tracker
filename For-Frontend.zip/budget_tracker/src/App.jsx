import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './app.scss'
import Dashboard from './Components/Dashboard/Dashboard'
import SingleBudget from './Pages/Single-Budget/SingleBudget'


function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Dashboard/>}/>
        <Route path='/budget' element={<SingleBudget/>}/>
        <Route path='/budget/:budgetName' element={<SingleBudget/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App
