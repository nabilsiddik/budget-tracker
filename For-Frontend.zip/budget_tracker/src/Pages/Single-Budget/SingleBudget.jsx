import React, { useContext, useEffect } from 'react'
import './singleBudget.scss'
import { useParams } from 'react-router-dom'
import { budgetTrackerContext } from '../../Context/budget-tracker-context/BudgetTrackerContext'
import Expense from '../../Components/Expense/Expense'

const SingleBudget = () => {
    const {budgets, expenses, totalSpentAmountForSpecificBudgetCategory, loadBudgets, loadExpense} = useContext(budgetTrackerContext)
    const {budgetName} = useParams()

    useEffect(()=>{
        loadBudgets()
        loadExpense()
      },[budgets,expenses])

  return (
    <div id='single-budget'>
      <div className="container">
        <div className="row">
            <div className="page-header my-3">
                <h1 className='text-center'>{budgetName}</h1>
            </div>
        </div>

        <div className="row budget-info">
            <div className="col-md-6">
                <h1 className='mb-3'>Budget Info</h1>
                {budgets.map(budget => {
                if(budget.budgetname.toLowerCase() === budgetName.toLowerCase()){
                    return <div key={budget.id} className="budget-info bg-primary text-light p-3 mb-3">
                        <h2>Budget Name: {budget.budgetname}</h2>
                        <h4>Budget Amount: {budget.budgetamount}</h4>
                        <h4>Total Spent: {totalSpentAmountForSpecificBudgetCategory(budget.budgetname)}</h4>
                        <h4>Total Ramain: {budget.budgetamount - totalSpentAmountForSpecificBudgetCategory(budget.budgetname)}</h4>
                    </div>
                    }
                })}
            </div>

            <div className="col-md-6">
                <h1 className='mb-3'>All Expenses of {budgetName}</h1>
                <div className="expenses">
                    {expenses.map(expense => {
                        if(expense.budgetcategory.toLowerCase() === budgetName.toLowerCase()){
                            return <Expense key={expense.id} expenseId = {expense.id} expenseName = {expense.expensename} expenseAmount = {expense.expenseamount} budgetCategory = {expense.budgetcategory} loadExpense = {loadExpense}/>
                        }
                    })}
                </div>
            </div>
        </div>
      </div>
    </div>
  )
}

export default SingleBudget
