import React, { useContext, useEffect, useState } from 'react'
import './addExpense.scss'
import axios, { all } from 'axios'
import { budgetTrackerContext } from '../../Context/budget-tracker-context/BudgetTrackerContext'

const AddExpense = ({ allBudgets, loadExpense }) => {

    const {expenses, totalSpentAmountForSpecificBudgetCategory } = useContext(budgetTrackerContext)

    const [expense, setExpense] = useState({
        expensename: "",
        expenseamount: 0,
        budgetcategory: ""
    })

    const { expensename, expenseamount, budgetcategory } = expense

    const [total, setTotal] = useState(0)

    const handleFocus = (e) => {
        const name = e.target.name
        setExpense({ ...expense, [name]: '' })
    }

    const handleInputChange = (e) => {
        const name = e.target.name
        setExpense(prevState => (
            { ...prevState, [name]: e.target.value }
        ))
    }


    const handleSubmit = async (e) => {
        e.preventDefault()

        if (expensename !== '') {
            axios.post("http://localhost:8080/expense", expense)
            loadExpense()
            setExpense((prevValue) => (
                { ...prevValue, expensename: "e.g: Clothes", expenseamount: 0 }
            ))
        } else {
            alert("Fillout the fields")
        }

    }


    return (
        <div id='add-expense'>
            <div className="card bg-danger text-light">
                <div className="card-body p-4">
                    <h3 className='card-title'>Create Expense</h3>
                    <form onSubmit={handleSubmit}>
                        <div className="row">
                            <div className="col-md-6">
                                <label className='form-label' htmlFor="expenseName">Expense Name</label>
                                <div className="input-group mb-3">
                                    <input
                                        onFocus={handleFocus}
                                        onChange={handleInputChange}
                                        id='expenseName' value={expensename} name='expensename' type="text" className='form-control' />
                                </div>
                            </div>
                            <div className="col-md-6">
                                <label className='form-label' htmlFor="budgetAmount">Expense Amount</label>
                                <div className="input-group">
                                    <input
                                        onFocus={handleFocus}
                                        onChange={handleInputChange}
                                        type="number" value={expenseamount} name='expenseamount' className='form-control' />
                                </div>
                            </div>
                        </div>
                        {allBudgets.length != 0 &&
                            <div className="row">
                                <label htmlFor="budgetCategory" className='form-label'>Budget Category</label>
                                <div className="input-group">
                                    <select name='budgetcategory' onChange={handleInputChange} className='form-control'>
                                        <option defaultValue value="Select a Budget Category">Select a Budget Category</option>
                                        {allBudgets.map(budget => {
                                            return <option key={budget.id} >{budget.budgetname}</option>
                                        })}
                                    </select>

                                </div>
                            </div>
                        }


                        <div className="input-group">
                            <input type="submit" className='btn btn-dark btn-lg mt-4' value="Add Expense" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default AddExpense
