import { useContext, useEffect } from 'react'
import './dashboard.scss'

import AddBudget from './../Add-Budget/AddBudget';
import AddExpense from './../Add-Expense/AddExpense';
import Budget from './../Budget/Budget';
import Expense from './../Expense/Expense';
import { budgetTrackerContext } from '../../Context/budget-tracker-context/BudgetTrackerContext';

function Dashboard() {

  const {budgets, expenses, loadBudgets, loadExpense} = useContext(budgetTrackerContext)

  useEffect(()=>{
    loadBudgets()
    loadExpense()
  },[budgets,expenses])


  return (
    <div id='budget-tracker'>
      <div className="container">
        <h1 className='text-center my-4'>Welcome to Budget Tracker</h1>
        <div className="row">
          <div className="col-md-6">
            <AddBudget allBudgets = {budgets} loadBudgets = {loadBudgets}/>
          </div>
          <div className="col-md-6">
            <AddExpense allBudgets = {budgets} allExpenses = {expenses} loadExpense = {loadExpense} />
          </div>
        </div>

        <div className="row mt-5">
          <div className="col-md-7">
            <h3>Existing Budgets</h3>
            <div id="all-budgets">
              {budgets.map((budget) => {
                return <Budget key={budget.id} budgetId={budget.id} budgetName = {budget.budgetname} budgetAmount={budget.budgetamount} loadBudget={loadBudgets}/>
              })}
            </div>
          </div>

          <div className="col-md-5">
            <h3>Recent Expenses</h3>
            {expenses.map(expense => {
              return <Expense key={expense.id} expenseId = {expense.id} expenseName = {expense.expensename} expenseAmount = {expense.expenseamount} budgetCategory = {expense.budgetcategory} loadExpense = {loadExpense}/>
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
