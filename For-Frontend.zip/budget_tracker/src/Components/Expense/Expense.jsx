import React, { useContext } from 'react'
import './expense.scss'
import { budgetTrackerContext } from '../../Context/budget-tracker-context/BudgetTrackerContext'

const Expense = ({ expenseName, expenseAmount, budgetCategory, expenseId }) => {

  const {deleteExpense} = useContext(budgetTrackerContext)

  return (
    <div id='expense'>
      <div className="card p-2 bg-warning">
        <div className="card-body d-flex align-items-center justify-content-between">
          <div className="header-left">
            <div className="expense-name">
              <h5 className='card-title'>Expense Name: {expenseName}</h5>
            </div>
            <div className="expense-amount">
              <h5 className="card-title">Expense Amount: BDT {expenseAmount}</h5>
            </div>
            <div className="expense-on">
              <h5 className="card-title">Expense on: {budgetCategory}</h5>
            </div>
          </div>
          <div className="header-right">
            <button
              onClick={() => {
                deleteExpense(expenseId)
              }}
              className='btn btn-danger  d-block'>Delete</button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Expense
