import React, { useContext, useState } from 'react'
import './addBudget.scss'
import axios from 'axios'
import { budgetTrackerContext } from '../../Context/budget-tracker-context/BudgetTrackerContext'

const AddBudget = () => {

    const {loadBudgets, budgets, totalSpentAmountForSpecificBudgetCategory} = useContext(budgetTrackerContext)

    const [budget, setBudget] = useState({
      budgetname: "e.g: Personal",
      budgetamount: 0,
    })

    const {budgetname, budgetamount} = budget

    const handleOnFocus = (e) => {
      setBudget({...budget, [e.target.name]: ''})
    }

    const handleInputChange = (e) => {
      const name = e.target.name
      setBudget(prevBudget => {
        return {...prevBudget, [name]: e.target.value}
      })

    }

    const handleSubmit = async (e) => {
      e.preventDefault()

      const isBudgetNameAlreadyExist = budgets.find((budget => budget.budgetname.toLowerCase() === budgetname.toLowerCase()))

      if(isBudgetNameAlreadyExist){
        alert("Budget Name Already Exist, PLease use another Budget Name")
      }else{
        await axios.post("http://localhost:8080/budget", budget)
      }

      setBudget({
        budgetname: "e.g: Personal",
        budgetamount: 0
      })

      // Load budgets
      loadBudgets()
    }

  return (
    <div id='add-budget'>
      <div className="card bg-success text-light">
        <div className="card-body p-4">
            <h3 className='card-title'>Create Budget</h3>
            <form onSubmit={handleSubmit}>
                <label className='form-label' htmlFor="budgetName">Budget Name</label>
                <div className="input-group mb-3">
                    <input
                    onChange={(e)=>{handleInputChange(e)}}
                    onFocus={handleOnFocus}
                    id='budgetName' name='budgetname' value={budgetname} type="text" className='form-control' />
                </div>

                <label className='form-label' htmlFor="budgetAmount">Budget Amount</label>
                <div className="input-group">
                    <input
                    onChange={(e)=>{handleInputChange(e)}}
                    onFocus={handleOnFocus}
                    type="number" name='budgetamount' value={budgetamount} className='form-control  ' />
                </div>

                <div className="input-group">
                    <input type="submit" className='btn btn-warning btn-lg mt-4' value="Add Budget" />
                </div>
            </form>
        </div>
      </div>
    </div>
  )
}

export default AddBudget
