import axios from 'axios'
import React, { useContext, useEffect } from 'react'
import { budgetTrackerContext } from '../../Context/budget-tracker-context/BudgetTrackerContext'
import { Link } from 'react-router-dom'

const Budget = ({budgetName, budgetAmount, budgetId}) => {
    
    const {totalSpentAmountForSpecificBudgetCategory, loadBudgets, deleteBudget, expenses} = useContext(budgetTrackerContext)




  return (
    <div id='budget'>
      <div className="card p-3 bg-dark text-light">
      <div className="card-header d-flex align-items-center justify-content-between">
            <div className="title">
                <h5 className="card-title">{budgetName}</h5>
            </div>
            <div className="budget">
                <h5 className="card-title">Budgeted: BDT {budgetAmount}</h5>
            </div>
        </div>
        <div className="card-body">
            <div className="calculations d-flex align-items-center justify-content-between">
                <div className="spent">
                    <h6 className='card-title'>Spent: BDT {totalSpentAmountForSpecificBudgetCategory(budgetName)}</h6>
                </div>
                <div className="remain">
                    <h6 className='card-title'>Remain: {budgetAmount - totalSpentAmountForSpecificBudgetCategory(budgetName)}</h6>
                </div>
            </div>
        </div>

        <div className="card-footer">
            <div className='d-flex align-items-center justify-content-between'>
                <Link to={`/budget/${budgetName}`}>
                    <button className='btn btn-warning'>View Details</button>
                </Link>
                <button
                    onClick={()=> {
                        deleteBudget(budgetId, budgetName)
                    }}
                className='btn btn-danger'>Delete Budget</button>
            </div>
        </div>
      </div>
    </div>
  )
}

export default Budget
