package com.budgettracker.budgettracker.controller;

import com.budgettracker.budgettracker.model.Budget;
import com.budgettracker.budgettracker.repository.BudgetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class BudgetController {

    @Autowired
    private BudgetRepository budgetRepository;

    @PostMapping("/budget")
    Budget newBudget(@RequestBody Budget newBudget){
        return budgetRepository.save(newBudget);
    }

    @GetMapping("/budget")
    List<Budget> getAllBudget(){
        return budgetRepository.findAll();
    }

    @DeleteMapping("/budget/{id}")
    String deleteBudget(@PathVariable Long id){
        if(!budgetRepository.existsById(id)){
            return "Budget with id " +id+ " is not exist";
        }
        budgetRepository.deleteById(id);
        return "Budget with id " +id+ " has been deleted successfully";
    }
}
