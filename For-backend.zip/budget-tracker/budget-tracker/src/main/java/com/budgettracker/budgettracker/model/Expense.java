package com.budgettracker.budgettracker.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Expense {
    @Id
    @GeneratedValue
    private Long id;
    private String expensename;
    private int expenseamount;
    private String budgetcategory;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getExpensename() {
        return expensename;
    }

    public void setExpensename(String expensename) {
        this.expensename = expensename;
    }

    public int getExpenseamount() {
        return expenseamount;
    }

    public void setExpenseamount(int expenseamount) {
        this.expenseamount = expenseamount;
    }

    public String getBudgetcategory() {
        return budgetcategory;
    }

    public void setBudgetcategory(String budgetcategory) {
        this.budgetcategory = budgetcategory;
    }
}
