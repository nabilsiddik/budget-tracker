package com.budgettracker.budgettracker.controller;

import com.budgettracker.budgettracker.model.Expense;
import com.budgettracker.budgettracker.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class ExpenseController {

    @Autowired
    private ExpenseRepository expenseRepository;

    @PostMapping("/expense")
    Expense newExpense(@RequestBody Expense newExpense){
        return expenseRepository.save(newExpense);
    }

    @GetMapping("/expense")
    List<Expense> getAllExpense(){
        return expenseRepository.findAll();
    }

    @DeleteMapping("/expense/{id}")
    String deleteExpense(@PathVariable Long id){
        if(!expenseRepository.existsById(id)){
            return "Expense with id " +id+ " is not exist";
        }
        expenseRepository.deleteById(id);
        return "Expense with id " +id+ " has been deleted successfully";
    }
}
